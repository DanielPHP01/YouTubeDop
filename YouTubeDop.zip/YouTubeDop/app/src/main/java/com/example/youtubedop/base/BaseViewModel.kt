package com.example.youtubedop.base

import androidx.lifecycle.ViewModel

open class BaseViewModel: ViewModel()